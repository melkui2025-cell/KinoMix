package ru.kinomix.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

private data class Provider(val name: String, val url: String, val paid: Boolean)
private data class Film(
    val title: String, val year: Int, val genre: String,
    val description: String, val providers: List<Provider>
) { val hasFreeOption get() = providers.any { !it.paid } }

private data class FreeFilm(
    val identifier: String, val title: String, val year: String?
) {
    val watchUrl: String get() = "https://archive.org/details/$identifier"
}

private val catalog = listOf(
    Film("Чебурашка", 2023, "Комедия, семейный",
        "История о необычном ушастом существе, которое попадает в приморский город.",
        listOf(Provider("Кинопоиск", "https://www.kinopoisk.ru/", true),
               Provider("START", "https://start.ru/", true))),
    Film("Последний богатырь", 2017, "Фэнтези, приключения",
        "Московский парень оказывается в сказочном мире Белогорье.",
        listOf(Provider("Кинопоиск", "https://www.kinopoisk.ru/", true),
               Provider("Иви", "https://www.ivi.ru/", true))),
    Film("Кухня", 2012, "Комедия, сериал",
        "Комедийный сериал о жизни сотрудников московского ресторана.",
        listOf(Provider("СТС", "https://ctc.ru/", false),
               Provider("START", "https://start.ru/", true))),
    Film("Маша и Медведь", 2009, "Мультфильм, семейный",
        "Приключения непоседливой Маши и её терпеливого друга Медведя.",
        listOf(Provider("Официальный канал", "https://www.youtube.com/@MashaBearRUS", false),
               Provider("Кинопоиск", "https://www.kinopoisk.ru/", true))),
    Film("Три кота", 2015, "Мультфильм, семейный",
        "Повседневные приключения котят Коржика, Компота и Карамельки.",
        listOf(Provider("Официальный сайт", "https://trikota.tv/", false))),
    Film("Интерстеллар", 2014, "Фантастика, драма",
        "Экспедиция отправляется искать новый дом для человечества.",
        listOf(Provider("Кинопоиск", "https://www.kinopoisk.ru/", true),
               Provider("Okko", "https://okko.tv/", true)))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KinoMixApp() }
    }
}

private suspend fun searchInternetArchive(query: String): List<FreeFilm> =
    withContext(Dispatchers.IO) {
        val encoded = URLEncoder.encode(query.trim(), "UTF-8")
        val url = URL(
            "https://archive.org/advancedsearch.php?q=mediatype%3Amovies%20AND%20title%3A($encoded)" +
            "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=year&rows=25&page=1&output=json"
        )
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10000
            readTimeout = 15000
            setRequestProperty("User-Agent", "KinoMixAndroid/1.0")
        }
        try {
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val docs = JSONObject(body).getJSONObject("response").getJSONArray("docs")
            buildList {
                for (i in 0 until docs.length()) {
                    val item = docs.getJSONObject(i)
                    val id = item.optString("identifier")
                    val title = item.optString("title")
                    if (id.isNotBlank() && title.isNotBlank()) {
                        add(FreeFilm(id, title, item.optString("year").takeIf { it.isNotBlank() && it != "null" }))
                    }
                }
            }
        } finally {
            connection.disconnect()
        }
    }

@Composable
private fun KinoMixApp() {
    val bg = Color(0xFF101014)
    val panel = Color(0xFF1D1D24)
    val accent = Color(0xFFFF3D68)
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Все") }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    var showFavorites by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Film?>(null) }
    var freeResults by remember { mutableStateOf<List<FreeFilm>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var searchMessage by remember { mutableStateOf("Введи название и нажми «Найти бесплатно»") }
    var hasSearched by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val filtered = catalog.filter { film ->
        val matchesText = film.title.contains(query, ignoreCase = true) ||
                film.genre.contains(query, ignoreCase = true)
        val matchesFilter = when (filter) {
            "Бесплатные" -> film.hasFreeOption
            "Платные" -> film.providers.all { it.paid }
            else -> true
        }
        matchesText && matchesFilter && (!showFavorites || film.title in favorites)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = bg, surface = panel, primary = accent,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = bg) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("КИНОМИКС", color = accent, fontSize = 13.sp,
                            fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Text("Смотри, что нравится", fontSize = 25.sp,
                            fontWeight = FontWeight.ExtraBold)
                    }
                    IconButton(onClick = { showFavorites = !showFavorites }) {
                        Icon(Icons.Default.Favorite, null,
                            tint = if (showFavorites) accent else Color.LightGray)
                    }
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Название фильма или жанр…") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accent, unfocusedBorderColor = Color(0xFF393943),
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White
                    )
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (query.isNotBlank() && !searching) {
                            searching = true
                            hasSearched = true
                            searchMessage = "Ищем бесплатные фильмы…"
                            freeResults = emptyList()
                            // LaunchedEffect below performs the network request.
                        }
                    },
                    enabled = query.isNotBlank() && !searching,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Icon(Icons.Default.Search, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Найти бесплатно")
                }

                LaunchedEffect(searching, query) {
                    if (searching) {
                        try {
                            freeResults = searchInternetArchive(query)
                            searchMessage = if (freeResults.isEmpty())
                                "В открытом архиве совпадений не найдено."
                            else "Найдено в открытом архиве: ${freeResults.size}"
                        } catch (e: Exception) {
                            searchMessage = "Не удалось выполнить поиск. Проверь интернет и попробуй ещё раз."
                        } finally {
                            searching = false
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                Text("БЕСПЛАТНЫЙ ПОИСК", color = Color(0xFF9B9BA8),
                    fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(searchMessage, color = Color(0xFFB5B5C0), fontSize = 12.sp)
                if (searching) {
                    LinearProgressIndicator(Modifier.fillMaxWidth(), color = accent)
                }
                if (hasSearched && freeResults.isNotEmpty()) {
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 270.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        items(freeResults) { item ->
                            Row(
                                Modifier.fillMaxWidth().background(panel, RoundedCornerShape(12.dp))
                                    .clickable {
                                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.watchUrl)))
                                    }.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(item.title, fontWeight = FontWeight.SemiBold)
                                    Text("Internet Archive • ${item.year ?: "год не указан"}",
                                        color = Color(0xFF66D9A6), fontSize = 11.sp)
                                }
                                Text("Открыть ↗", color = accent, fontSize = 12.sp)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Все", "Бесплатные", "Платные").forEach { option ->
                        FilterChip(
                            selected = filter == option, onClick = { filter = option },
                            label = { Text(option) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = accent, selectedLabelColor = Color.White
                            )
                        )
                    }
                }
                Text(if (showFavorites) "ИЗБРАННОЕ" else "КАТАЛОГ",
                    color = Color(0xFF9B9BA8), fontSize = 12.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.height(8.dp))
                if (selected != null) {
                    FilmDetails(
                        film = selected!!, isFavorite = selected!!.title in favorites,
                        onBack = { selected = null },
                        onFavorite = {
                            favorites = if (selected!!.title in favorites)
                                favorites - selected!!.title else favorites + selected!!.title
                        },
                        onOpen = { url ->
                            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                        }, accent = accent
                    )
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 24.dp)) {
                        items(filtered) { film ->
                            FilmCard(
                                film = film, isFavorite = film.title in favorites,
                                panel = panel, accent = accent,
                                onClick = { selected = film },
                                onFavorite = {
                                    favorites = if (film.title in favorites)
                                        favorites - film.title else favorites + film.title
                                }
                            )
                        }
                        if (filtered.isEmpty()) item {
                            Text("Ничего не найдено. Попробуй другой запрос.",
                                color = Color.LightGray, modifier = Modifier.padding(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FilmCard(
    film: Film, isFavorite: Boolean, panel: Color, accent: Color,
    onClick: () -> Unit, onFavorite: () -> Unit
) {
    Row(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(18.dp))
        .clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(width = 76.dp, height = 104.dp)
            .background(Color(0xFF343440), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center) {
            Text("▶", color = accent, fontSize = 28.sp)
        }
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(film.title, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text("${film.year} • ${film.genre}", color = Color(0xFFB5B5C0), fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Text(if (film.hasFreeOption) "Есть бесплатная площадка" else "Платный просмотр",
                color = if (film.hasFreeOption) Color(0xFF66D9A6) else Color(0xFFFFC16B),
                fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Text("${film.providers.size} площадок", color = Color(0xFF9999A5), fontSize = 11.sp)
        }
        IconButton(onClick = onFavorite) {
            Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                null, tint = if (isFavorite) accent else Color.LightGray)
        }
    }
}

@Composable
private fun FilmDetails(
    film: Film, isFavorite: Boolean, onBack: () -> Unit,
    onFavorite: () -> Unit, onOpen: (String) -> Unit, accent: Color
) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text("← Назад", color = accent, modifier = Modifier.clickable { onBack() })
        Spacer(Modifier.height(20.dp))
        Text(film.title, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
        Text("${film.year} • ${film.genre}", color = Color.LightGray)
        Spacer(Modifier.height(14.dp))
        Text(film.description, fontSize = 15.sp, lineHeight = 22.sp)
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Площадки", fontSize = 19.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f))
            TextButton(onClick = onFavorite) {
                Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    null, tint = accent)
                Text("Избранное")
            }
        }
        film.providers.forEach { provider ->
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)
                .background(Color(0xFF1D1D24), RoundedCornerShape(12.dp))
                .clickable { onOpen(provider.url) }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(provider.name, fontWeight = FontWeight.Bold)
                    Text(if (provider.paid) "Подписка или оплата могут потребоваться"
                         else "Есть бесплатный официальный контент",
                        color = if (provider.paid) Color(0xFFFFC16B) else Color(0xFF66D9A6),
                        fontSize = 11.sp)
                }
                Text("Открыть ↗", color = accent, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Доступность и цена меняются. Проверяй условия на площадке.",
            color = Color(0xFF9999A5), fontSize = 12.sp)
    }
}
